export const environment = {
   production: true,
   baseUrl: "https://localhost:7168/api"
};
