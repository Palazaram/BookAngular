export interface Book{
   id: number,
   title: string,
   createdAt: Date,
   description: string,
   pageCount: number
}