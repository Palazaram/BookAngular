export interface Status {
   statusCode: number,
   message: string
}