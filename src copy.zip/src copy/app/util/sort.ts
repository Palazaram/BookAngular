// export class Sort {
//    private sortorder = 1;

//    private collator = new Intl.Collator (undefined, {
//       numeric: true, 
//       sensitivity: "base"
//    });


// constructor() {
// }
// public startsort (property, order, type = «") {
// if (order see "desc this.sortOrder
// -1
// }
// return (a, b) => {
// if (type === "date") {
// return this.sortData (new Date(a[property]), new Date(b[property])):
// }
// else {
// return this. collator.compare(a[property], b[property]) * this. sortorder;
// private sortdata(a, b) {
// if (a ‹ b) ‹
// return -1 * this. sortorder;
// } else if (a › b) {
// return 1 * this. sortorder:
// } else {
// return
// }